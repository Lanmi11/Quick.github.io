# Brightline – Landing Page Template

A clean, responsive, single-file landing page. No build tools, no frameworks, no JavaScript.
Open `landing-template.html` in any browser to preview it.

## What's inside
- Sticky header, hero, social proof strip, features, how it works, testimonial, 3-tier pricing, FAQ, final call to action, footer
- Light and dark mode (follows the visitor's system setting)
- Responsive from phones to wide desktops
- Visible keyboard focus and reduced-motion support

## Quick start
1. Open `landing-template.html` in a text editor (Notepad, VS Code, etc.).
2. Replace the placeholder text. Search for `Brightline`, `Starter`, `Team`, `Studio`.
3. Point every `href="#"` to your own page, checkout or sign-up link.
4. Upload the file to any host (Netlify, GitHub Pages, Cloudflare Pages, or your own hosting).

## Change the colors
Find the `:root` block at the top of the `<style>` section:

| Variable   | What it controls                  |
|------------|-----------------------------------|
| `--bg`     | Page background                   |
| `--soft`   | Soft panels and frame background  |
| `--ink`    | Main text                         |
| `--muted`  | Secondary text                    |
| `--line`   | Borders and dividers              |
| `--accent` | Buttons, links, highlights        |
| `--hi`     | Yellow highlight (logo, tags)     |

Dark-mode colors are in the `@media (prefers-color-scheme:dark)` block right below it.

## Change the fonts
1. Pick two fonts on fonts.google.com and replace the Google Fonts `<link>` in the `<head>`.
2. Update `--font-head` and `--font-body` in `:root`.

## Add or remove sections
Each `<section>` is independent. Delete one, or copy and move it, without breaking the others.

## Add your product image
Replace the `<div class="frame">...</div>` in the hero with:
`<img src="your-screenshot.png" alt="Describe your product" style="width:100%;border-radius:14px">`

## Support
Questions? Contact: micaga04@gmail.com
